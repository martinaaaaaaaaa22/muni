<!DOCTYPE html>
<html >
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
 
        <form action="guardar.php"  method="POST" enctype="multipart/form-data">
            <input type="text" REQUIRED name="nombre" placeholder="Nombre..." value="" />
            <input type="file" REQUIRED name="imagen"  />
            <input type="text" REQUIRED name="mas" placeholder='Ingrese descripcion' value="" />
            <input type="submit" value="Aceptar" />
            
            
        
        </form>
    
  
    
</body>
</html>