<?php
    $conexion= new mysqli("localhost","root","","municipalidad");

    





?>