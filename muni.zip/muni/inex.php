<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@300&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    
    <title>Municipalidad</title>
</head>
<body>
    <!-- contenedor_general -->
    <div class="contenedor">
        
        <!-- contenedor_del_logo -->
        <div class="contenedor_logo">

            <img src="logo.png" class="log">

        </div>

        <!-- contenedor_del_fondo -->
        <div class="contenedor_imagen" >
        </div>

        
        
        <!-- contenedor_del_mapa -->
        <div class="contenedor_mapa">

            <img src="mapa.png" class="mapa">

        </div>

        <!-- contenedor_de_texto -->
        <div class="contenedor_texto">
            <p class="text">
                Alta Gracia es un rincón del Valle de Paravachasca donde la cultura <br>
                es palpable en cada atractivo.Es uno de los destinos turísticos mas próximos 
                a la ciudad de Córdoba. <br>Como gran atractivo, en pleno centro histórico se encuentra<br>
                una de las cinco Estancias Jesuíticas declaradas Patrimonio de la Humanidad por la UNESCO.
            </p>

        </div>
      

        <!-- contenedor_lugares_para_visitar -->
        <div class="contenedor_lugares_visitar">
            
            <h1>L U G A R E S  P A R A  V I S I T A R</h1>

        </div>

       
        <div class="tarjetas">

            <?php

                include("conexion.php");

                $query="SELECT * FROM lugares";
                $resultado= $conexion->query($query);
                while($row = $resultado->fetch_assoc()){


            ?>

            <div class="card">
            
                <div class="card-img">
                    <img class="fondo" src="data:image/jpg;base64,<?php echo base64_encode($row['imagen']);?>">
                </div>
                <div class="card-info">
                    <div class="card-text">
                    <p class="text-title"><?php echo $row['nombre']; ?></p>
                    <p class="text-subtitle"><?php echo $row['mas']; ?></p>
                    </div>
                    <div class="card-icon">
                    <svg viewBox="0 0 28 25">
                        <path d="M13.145 2.13l1.94-1.867 12.178 12-12.178 12-1.94-1.867 8.931-8.8H.737V10.93h21.339z"></path>
                    </svg>
                    </div>
                </div>

            </div>
            
           
        
            <?php
                        
                }
                        

            ?>

        </div>

</body>
        




    
</body>

<!-- estilo -->

.

<style>
/* /////////IMAGENES LUGARES PARA VISITAR//////////////// */

    .tarjetas{
        grid-column-start: 1;
        grid-column-end: 4;

        grid-row-start: 7;
        grid-row-end: 8;

        display: grid;
        grid-gap: 10px;
        grid-template-columns:repeat( 4,300px);
        grid-template-rows: repeat(6,300px);

        padding-left:12px;
        padding-right:12px;

        animation:fadeInDown;
        animation-duration: 2s; 
        


    }

    .fondo{

        width:100%;
        height:100%;
    }

    .card {
        
        width: 300px;
        height: 300px;
        position: relative;
        background: #f5f5f5;
        transition: box-shadow .3s cubic-bezier(0.175, 0.885, 0.32, 1.275);

    }

    .card-img {

        position: absolute;
        height: 100%;
        width: 100%;
    
    }

    .card-info {

        position: absolute;
        width: 300px;
        bottom: 0;
        padding: 1rem;
        display: flex;
        align-items: flex-end;
        justify-content: space-between;
        background:rgba(255, 255, 255, 0.507);
        visibility:hidden;
        
    }

    .card-icon {

        opacity: 0;
        transform: translateX(-20%);
        width: 2em;
        height: 2em;
        transition: all .3s ease-in-out;
    }

    svg {

        --size: 20px;
        width: var(--size);
        height: var(--size);
    }

    /*Text*/
    p {
        line-height: 140%;
    }

    .text-title {
        font-weight: 900;
        font-size: 18px;
    }

    .text-subtitle {
        color: #333;
        font-weight: 500;
        font-size: 16px;
    
       
    }

    /*Hover*/
    .card:hover {
        box-shadow: 0 10px 20px 4px rgba(35, 35, 35, .1);
    }

    .card:hover .card-icon {
        opacity: 1;
        transform: translateX(20%);
    }

    .card:hover .card-info {
        opacity: 1;
        
        visibility:visible;
        height:268px;
        width:268px;

        -ms-word-break: break-all;
        word-break: break-all;
        

    }


        /* ///////FIN TARJETAS///////// */


/* 
/////////CONTENEDOR DE TODO///// */
    .contenedor{
        display: grid;

        grid-gap: 10px;
        grid-template-columns:repeat( 3,420px);
        grid-template-rows: repeat(8,300px);

        font-family: 'Mulish', sans-serif;
        
    }
    


/*     
//////CONTENEDOR LOGO///////// */
    .contenedor_logo{
        grid-column-start: 2;
        grid-column-end: 3;

        grid-row-start: 3;
        grid-row-end: 4;

        display: grid;
 
    }

/* //////LOGO/////// */

    .log{
        max-width: 120%;
        max-height: 120%;

        display: grid;

        align-items: center;
        justify-self: center;

       
    }

    .log:hover{
        filter:drop-shadow(0 0 10px rgba(0, 0, 0, 0.637));
        transition: all 0.7s;
       
    }

/* ////////CONTENEDOR IMAGEN DE FONDO/////////// */

    .contenedor_imagen{
        display: grid;

        grid-row-start: 1;
        grid-row-end: 3;

        grid-column-start: 1;
        grid-column-end: 5;

        background-image: url("Alta\ gracia.png");

    }

/* /////CONTENEDOR DE IMAGEN DE MAPA DE ALTA GRACIA////// */
    .contenedor_mapa{
        display: grid;

        grid-column-start: 1;
        grid-column-end: 2;

        grid-row-start: 4;
        grid-row-end: 5;

        margin-top: 40%;

    }

/* //////MAPA DE ALTA GRACIA//////// */

    .mapa{
        max-width: 75%;
        max-height: 75%;

        display: grid;

        align-items: center;
        justify-self: center;

    }

/* ////CONTENEDOR DE INFO DE ALTA GRACIA//////// */

    .contenedor_texto{
        display: grid;

        grid-column-start: 2;
        grid-column-end: 4;

        grid-row-start: 4;
        grid-row-end: 6;

        margin-top: 21%;
        
        

        font-size: 25px;

        text-align:left;
        align-items: center;

        border-color:  rgba(22, 21, 21, 0.5);
        border-width: 4px ;
        border-style: solid  ;
        border-bottom: none;
        border-top: none;
        border-right: none;

        

    }

/* //////TEXTO SOBRE AG///////// */

    .text{
        margin-left: 5%;  
    }


/* //////////CONTENEDOR LUGARES PARA VISITAR/////// */
    .contenedor_lugares_visitar{
        display: grid;

        grid-column-start: 1;
        grid-column-end: 4;

        grid-row-start: 6;
        grid-row-end: 7;

        text-align:center;
        align-items: center;

        font-size: 20px;

        margin-top: 10%;

    }

    /*     
//////TITULO LUGARES PARA VISITAR/////// */
    h1{
        letter-spacing: 5px;

        animation:fadeInDown;
        animation-duration: 5s; 
    }

    

</style>

</html>